<?php
#KEKALKAN SETUP INI
#SET TIME ZONE WAKTU
date_default_timezone_set("Asia/Kuala_Lumpur");
$tarikhkini=date("Y-m-d");
$masakini=date("H:i:s");
#SETTING DATABASE
$host="localhost";
$user="root";

#UBAH MASA DISINI NAMA DB
$db="hadir1";
$password="";

#SAMBUNGAN PANGKALAN DATA
$con = mysqli_connect($host,$user,$password,$db);

#PAPARAN MSG JIKA SAMBUNGAN GAGAL
if (mysqli_connect_errno()){
echo "Database tidak terhubung!: ".mysqli_connect_error();
}

#UBAH DISINI UNTUK TETAPAN SISTEM
$namasys = "SISTEM KEHADIRAN";
$namasys1 = "SISTEM KEHADIRAN AHLI SILAT GAYONG";
$motto= "Setia & Jujur";
?>