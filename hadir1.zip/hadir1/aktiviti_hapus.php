<?php
// SAMBUNG KE PANGKALAN DATA
require 'database.php';

// DAPATKAN ID AKTIVITI DARIPADA URL
$AktivitiDel = $_GET['id'];

// LAKUKAN PENGHAPUSAN AKTIVITI DARI PANGKALAN DATA
mysqli_query($con, "DELETE FROM aktiviti WHERE kod='$AktivitiDel'");

// PAPAR MESEJ BERJAYA DAN ALIHKAN PELAWAT KE LAMAN AKTIVITI SEMULA
echo "<script>alert('Aktiviti berjaya dihapuskan'); window.location='aktiviti.php'</script>";
?>
