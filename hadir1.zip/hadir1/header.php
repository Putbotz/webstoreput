<?php
#MULA SESI
session_start();
#SAMBUNG P.DATA
require 'database.php';
?>
<html>
<!-- PANGGILAN CSS EXTERNAL -->
<link rel="stylesheet" type="text/css" href="style.css">
<!-- NAMA SISTEM DI TITLE BAR BROWSER -->
<title><?php echo $namasys;?></title>
<!-- PAPAR MAKLUMAT SISTEM DIB ANER -->
<div class="header">
<br>
<h1><?php echo $namasys1;?></h1>
<h3><?php echo $motto;?></h3>
<!-- PAPAR UTLITI BUTANG ZOOM IN OUT WARNA-->
<?php include 'utiliti.php'; ?>
</div>
</html>