<?php
session_start(); // Corrected function name
session_destroy();
header("location:index.php");
?>
