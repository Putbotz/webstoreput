<?php

include 'header.php' ;

if (isset($_POST['hantar'])) {
    $data1 = $_POST['aktiviti'];
    $data2 = $_POST['tarikh'];

    // Check for duplicate date
    $semakan = mysqli_query($con, "SELECT * FROM aktiviti WHERE tarikhAktiviti='$data2'");
    $detail = mysqli_num_rows($semakan);
    if ($detail != 0) {
        echo "<script>alert('RALAT! Pertembungan tarikh, Sila pilih tarikh lain');</script>";
        echo "<script>window.location='aktiviti_tambah.php'</script>";
    } else {
        // Insert record into the table
        mysqli_query($con, "INSERT INTO aktiviti VALUES (NULL, '$data1', '$data2')") or die(mysqli_error());
        echo "<script>alert('Aktiviti berjaya ditambah');</script>";
        echo "<script>window.location='aktiviti.php'</script>";
    }
}

?>

<!-- START HTML -->
<html>
<head>
    <title>TAMBAH AKTIVITI BARU</title>
</head>
<body>

<!-- Include Menu -->
<div id="menu" style="color: white;"> <!-- Set text color to white for the menu -->
    <?php include 'menu.php'; ?>
</div>

<!-- Content -->
<div id="isi" style="color: white;">
<h2><p>TAMBAH AKTIVITI BARU</p></h2>
    <form method="POST">
        <p style="color: white;">KETERANGAN AKTIVITI<br>
            <input type="text" name="aktiviti" placeholder="Taip di sini" size="60%" required autofocus></p>
        <p style="color: white;">TARIKH<br>
            <input type="date" name="tarikh" size="30%" required></p>
        <div>
            <button name="hantar" type="submit">SIMPAN</button>
            <button type="reset">RESET</button>
        </div>
        <p><font color='red'>*Pastikan maklumat anda betul sebelum simpan.</font></p>
    </form>
</div>
</body>
</html>
