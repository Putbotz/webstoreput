<?php
// Include database connection
require 'database.php';

// Get the value of 'hp' parameter from the query string
$hpDel = $_GET['hp'];

// Construct the SQL DELETE query
$query = "DELETE FROM hp WHERE nomHp='$hpDel'";

// Execute the DELETE query
$result = mysqli_query($con, $query);

// Check if the query was successful
if ($result) {
    // If successful, display a success message using JavaScript
    echo "<script>alert('Ahli berjaya dihapuskan'); window.location='senarai_ahli.php'</script>";
} else {
    // If an error occurred, display an error message
    echo "<script>alert('Gagal menghapus ahli'); window.location='senarai_ahli.php'</script>";
}

// Close the database connection
mysqli_close($con);
?>
