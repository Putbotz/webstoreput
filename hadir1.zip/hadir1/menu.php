<?php
?>
<html>
<div id="menu" style="color: white;">
<?php
if (isset($_SESSION['level']) && $_SESSION['level'] == "ADMIN") {
?>
    <!-- ARAS LOGIN - ADMIN-->
    <h4>MENU PENTADBIR</h4>
    <ul>
        <li><a href="dashboard.php" style="color: white;">HOME</a></li>
        <li><a href="aktiviti.php" style="color: white;">SENARAI AKTIVITI</a></li>
        <li><a href="senarai_ahli.php" style="color: white;">SENARAI AHLI</a></li>
        <li><a href="carian.php" style="color: white;">CARIAN KEHADIRAN</a></li>
        <li><a href="laporan1.php" style="color: white;">LAPORAN KEHADIRAN</a></li>
        <li><a href="laporan2.php" style="color: white;">LAPORAN TIDAK HADIR</a></li>
        <li><a href="logout.php" style="color: white;">KELUAR</a></li>
    </ul>
<?php
} else {
?>
    <!-- #ARAS LOGIN - PENGGUNA -->
    <h4>MENU AHLI</h4>
    <ul>
        <li><a href="dashboard.php" style="color: white;">HOME</a></li>
        <li><a href="logout.php" style="color: white;">KELUAR</a></li>
    </ul>
<?php
}
?>
</div>
</html>
