<?php 
include 'header.php'; 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
    <style>
        /* Set font color to white for the body */
        body {
            color: white;
        }

        /* Override font color to black for table elements */
        table, th, td {
            color: black;
        }
    </style>
</head>

<body>

    <!-- PANGGIL MENU -->
    <div id="menu">
        <?php include 'menu.php'; ?>
    </div>

    <!-- PAPAR ISI -->
    <div id="isi">
        <!-- PAPAR UCAPAN -->
        <h3>SELAMAT DATANG <?php
                            echo strtoupper($_SESSION['nama']);
                            echo "</h3>TARIKH:" . $tarikhkini;
                            echo "<br>MASA:" . $masakini; ?>
        <hr>
        <!-- PAPAR PAGE -->
        <?php
        if ($_SESSION['level'] == "PENGGUNA") {
            include 'hadir.php';
        }
        ?>
    </div>

</body>

</html>
