<?php
#KEKALKAN SETUP INI
#SET TIME ZON WAKTU
date_default_timezone_set("Asia/Kuala_lumpur");
$tarikhkini=date("Y-m-d");
$masakini=("H:i:s");
#SETTING DATABASE
$host= "localhost";
$user= "root";

#UBAH DI SINI NAMA DB
$db="hadir2";
$password="";

#SAMBUNGAN PANGKALAN DATA
$con = mysqli_connect($host,$user,$password,$db);

#PAPARAN MSG JIKA SAMBUNGAN GAGAL
if (mysqli_connect_errno()){
echo "Database tidak berhubung!: ".mysqli_connect_error();
}

#UBAH DI SINI UNTUK TETAPAN SISTEM
$namsys = "TEPAT DAN CEKAP";
$namasys1 = "SISTEM KEHADIRAN AHLI PENGAKAP";
$motto= "Setia & Jujur";
?>