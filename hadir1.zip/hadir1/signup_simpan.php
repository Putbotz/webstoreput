<?php
require 'database.php'; // Include the database connection file

// Check if the form is submitted
if (isset($_POST['hantar'])) {
    // Check if gender is selected
    if ($_POST['jantina'] == NULL) {
        echo "<script>alert('Pilih Jantina');
        window.location='signup.php'</script>"; // Alert user and redirect if gender is not selected
    } else {
        // Retrieve values from the form
        $Kp = $_POST['nomkp']; // Identity card number
        $LP = $_POST['jantina']; // Gender
        $Nama = $_POST['nama']; // Name
        $Hp = $_POST['nomhp']; // Phone number
        
        // Generate password (last 6 digits of ID card number)
        $Pw = substr($Kp, 6);
        
        // Check if records already exist in the database
        $semakan1 = mysqli_query($con, "SELECT * FROM hp WHERE nomHp='$Hp'");
        $semakan2 = mysqli_query($con, "SELECT * FROM peserta WHERE nomKp='$Kp'");
        
        // Get the number of rows returned by the queries
        $detail1 = mysqli_num_rows($semakan1);
        $detail2 = mysqli_num_rows($semakan2);
        
        // If no records exist, insert new records
        if (($detail1 == 0) AND ($detail2 == 0)) {
            mysqli_query($con, "INSERT INTO hp VALUES ('$Hp', '$Nama')") or die(mysqli_error()); // Insert into hp table
            mysqli_query($con, "INSERT INTO peserta VALUES ('$Kp', '$LP', '$Pw', 'PENGGUNA', '$Hp')") or die(mysqli_error()); // Insert into peserta table
            echo "<script>alert('Pendaftaran berjaya');
            window.location='index.php'</script>"; // Success message and redirect
        } else {
            echo "<script>alert('Pendaftaran gagal, Semak Nombor KP/HP');
            window.location='signup.php'</script>"; // Failure message and redirect
        }
    }
}
?>
