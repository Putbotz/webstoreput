<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Handle the case where the user is not logged in
    // For example, you can redirect them to the login page
    header("Location: index.php");
    exit(); // Stop further execution
}

// Now you can safely access $_SESSION['user']
$KP = $_SESSION['user'];

require 'database.php'; 

// Rest of your code...
?>
