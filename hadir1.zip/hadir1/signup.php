<?php include 'header.php'; ?> 
<!-- Include header file -->
<html>
<!-- PANGGIL MENU -->
<div id="isi">
    <h2>PENDAFTARAN AHLI BARU</h2>
    <body style="color: white;"> <!-- Set font color to white -->
        <form method="POST" action="signup_simpan.php"> <!-- Form starts with method POST, action points to 'signup_simpan.php' -->
            <font color='red'>*Pastikan maklumat anda betul sebelum membuat pendaftaran.</font> <!-- Warning message -->
            <p>Nom Kad Pengenalan<br>
                <input type="text" name="nomkp" placeholder="Nombor KP tanpa tanda '-'" minlength='12' maxlength='12' size="30" onkeypress='return event.charCode >= 48 && event.charCode <=57' required autofocus><br>
                <font style='font-size:10px;color:red'>*Password adalah 6 digit akhir nom Kp dijana secara automatik.</font> <!-- Note about password generation -->
            </p>
            <p>Nama<br>
                <input type="text" name="nama" placeholder="Nama Anda" size="60" required> <!-- Input field for name -->
            </p>
            <p>Jantina<br>
                <select name="jantina"> <!-- Dropdown for gender selection -->
                    <option value="">PILIH</option>
                    <option value="LELAKI">LELAKI</option>
                    <option value="PEREMPUAN">PEREMPUAN</option>
                </select>
            </p>
            <p>Nom HP<br>
                <input type="text" name="nomhp" placeholder="Tanpa '-'" minlength='10' maxlength='14' size="30" onkeypress='return event.charCode >= 48 && event.charCode <=57' required> <!-- Input field for phone number -->
            </p>
            <br>
            <div>
                <button type="button" onclick="window.history.back();">KEMBALI</button> <!-- Back button -->
                <button name="hantar" type="submit">DAFTAR</button> <!-- Submit button -->
                <button type="reset">RESET</button> <!-- Reset button -->
            </div>
        </form>
    </body>
</div>
</html>
